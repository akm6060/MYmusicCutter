package com.mymusic.cutter

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * JavaScript bridge registered as window.MYmusicNativeCutter.
 *
 * Cutting is lossless (no re-encoding):
 *  - MP3: whole MPEG audio frames are copied, output .mp3
 *  - WAV: PCM bytes are copied, output .wav
 *  - MP4 / M4A / 3GP / AAC (H.264, H.265, AAC...): MediaExtractor + MediaMuxer, output .mp4 / .m4a
 *  - WebM (VP8/VP9 with Vorbis/Opus): MediaExtractor + MediaMuxer, output .webm
 * Video cuts start at the keyframe at or before the chosen start, so the selection is never shortened.
 */
class MYmusicNativeCutter(
    private val activity: Activity,
    private val webView: WebView
) {
    private val context: Context = activity.applicationContext
    private val lock = Any()
    private val worker = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)

    private class Picked(val uri: Uri, val name: String, val size: Long)
    private val picked = ArrayList<Picked>()

    private class Source(val uri: Uri?, val file: File?)

    // Fallback transfer (only used when the picked file cannot be matched).
    private var meta: JSONObject? = null
    private var inputFile: File? = null
    private var inputStream: FileOutputStream? = null

    fun shutdown() {
        worker.shutdown()
    }

    // ---------------------------------------------------------------- orientation / fullscreen

    @JavascriptInterface
    fun allowAutoRotation(): Boolean {
        activity.runOnUiThread {
            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
        return true
    }

    @JavascriptInterface
    fun lockLandscape(): Boolean {
        activity.runOnUiThread {
            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            (activity as? MainActivity)?.setFullscreenBars(true)
        }
        return true
    }

    @JavascriptInterface
    fun unlockOrientation(): Boolean {
        activity.runOnUiThread {
            (activity as? MainActivity)?.setFullscreenBars(false)
            activity.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
        return true
    }

    // ---------------------------------------------------------------- picked files

    /** Called by MainActivity with the files the user just chose. */
    fun rememberPicked(uris: Array<Uri>) {
        val found = uris.map { uri ->
            var name = uri.lastPathSegment ?: "media"
            var size = -1L
            try {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val s = c.getColumnIndex(OpenableColumns.SIZE)
                        if (n >= 0 && !c.isNull(n)) name = c.getString(n)
                        if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
                    }
                }
            } catch (_: Exception) {
            }
            Picked(uri, name, size)
        }
        synchronized(lock) {
            picked.addAll(found)
            while (picked.size > 200) picked.removeAt(0)
        }
    }

    private fun findPicked(name: String, size: Long): Uri? = synchronized(lock) {
        picked.lastOrNull { it.name == name && (size <= 0 || it.size <= 0 || it.size == size) }?.uri
    }

    /** Fast path: cut the file Android already gave us, without copying it through JavaScript. */
    @JavascriptInterface
    fun cutPickedFile(metaJson: String): Boolean {
        return try {
            val parsed = JSONObject(metaJson)
            val uri = findPicked(parsed.optString("fileName", ""), parsed.optLong("fileSizeBytes", -1L))
                ?: return false
            startJob(parsed, Source(uri, null))
        } catch (_: Exception) {
            false
        }
    }

    // ---------------------------------------------------------------- fallback chunk transfer

    @JavascriptInterface
    fun beginTransfer(metaJson: String): Boolean = synchronized(lock) {
        try {
            inputStream?.close()
            inputFile?.delete()
            val parsed = JSONObject(metaJson)
            val name = safeName(parsed.optString("fileName", "media"))
            val temp = File(context.cacheDir, "mymusic_${UUID.randomUUID()}_$name")
            meta = parsed
            inputFile = temp
            inputStream = FileOutputStream(temp)
            true
        } catch (_: Exception) {
            meta = null
            inputFile = null
            inputStream = null
            false
        }
    }

    @JavascriptInterface
    fun appendChunk(base64Chunk: String): Boolean = synchronized(lock) {
        try {
            val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
            val out = inputStream ?: return false
            out.write(bytes)
            true
        } catch (_: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun finishTransfer(): Boolean {
        val transfer: Pair<JSONObject, File> = synchronized(lock) {
            val stream = inputStream
            inputStream = null
            try {
                stream?.flush()
                stream?.close()
            } catch (_: Exception) {
                return false
            }
            val m = meta ?: return false
            val f = inputFile ?: return false
            meta = null
            inputFile = null
            Pair(m, f)
        }
        val jobMeta = transfer.first
        val jobFile = transfer.second
        val started = startJob(jobMeta, Source(null, jobFile))
        if (!started) jobFile.delete()
        return started
    }

    // ---------------------------------------------------------------- snapshot

    @JavascriptInterface
    fun saveSnapshot(base64Jpeg: String, fileName: String): Boolean {
        val bytes = try {
            Base64.decode(base64Jpeg, Base64.DEFAULT)
        } catch (_: Exception) {
            return false
        }
        worker.execute {
            val temp = File(context.cacheDir, "mymusic_snap_${UUID.randomUUID()}.jpg")
            try {
                temp.writeBytes(bytes)
                val stem = safeName(fileName.substringBeforeLast('.', fileName)).take(70)
                val saved = publishOutput(temp, Kind.IMAGE, "${stem}_${System.currentTimeMillis()}.jpg", "image/jpeg")
                notifyPage("Snapshot saved: $saved")
            } catch (e: Exception) {
                notifyPage("Snapshot failed: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                temp.delete()
            }
        }
        return true
    }

    // ---------------------------------------------------------------- job

    private fun startJob(jobMeta: JSONObject, source: Source): Boolean {
        if (!busy.compareAndSet(false, true)) {
            notifyPage("Please wait: the previous cut is still saving.")
            return true
        }
        worker.execute {
            val tempOutput = File(context.cacheDir, "mymusic_cut_${UUID.randomUUID()}.tmp")
            try {
                val isAudio = jobMeta.optString("mediaType", "video") == "audio"
                val mode = jobMeta.optString("mode", "keep")
                val startUs = (jobMeta.optDouble("startSeconds", 0.0) * 1_000_000).toLong()
                val endUs = (jobMeta.optDouble("endSeconds", 0.0) * 1_000_000).toLong()
                val name = jobMeta.optString("fileName", "media")
                require(startUs >= 0 && endUs > startUs) { "The selected cutting range is invalid." }

                val ranges: List<LongArray> = if (mode == "remove-middle") {
                    listOf(longArrayOf(0L, startUs), longArrayOf(endUs, Long.MAX_VALUE)).filter { it[1] > it[0] }
                } else {
                    listOf(longArrayOf(startUs, endUs))
                }

                val stem = safeName(name.substringBeforeLast('.', name)).take(70)
                val stamp = System.currentTimeMillis()
                val saved = when (detectFormat(source, name)) {
                    "mp3" -> {
                        cutMp3(source, tempOutput, ranges)
                        publishOutput(tempOutput, Kind.AUDIO, "${stem}_cut_$stamp.mp3", "audio/mpeg")
                    }
                    "wav" -> {
                        cutWav(source, tempOutput, ranges)
                        publishOutput(tempOutput, Kind.AUDIO, "${stem}_cut_$stamp.wav", "audio/wav")
                    }
                    else -> {
                        val webm = muxCut(source, tempOutput, isAudio, ranges)
                        val ext = if (webm) ".webm" else if (isAudio) ".m4a" else ".mp4"
                        val mime = when {
                            webm && isAudio -> "audio/webm"
                            webm -> "video/webm"
                            isAudio -> "audio/mp4"
                            else -> "video/mp4"
                        }
                        publishOutput(tempOutput, if (isAudio) Kind.AUDIO else Kind.VIDEO, "${stem}_cut_$stamp$ext", mime)
                    }
                }
                notifyPage("Saved cut: $saved")
            } catch (e: Exception) {
                notifyPage("Cut failed: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                tempOutput.delete()
                source.file?.delete()
                busy.set(false)
            }
        }
        return true
    }

    private fun openInput(source: Source): InputStream =
        source.file?.inputStream()
            ?: context.contentResolver.openInputStream(source.uri!!)
            ?: throw IllegalStateException("Android could not open the selected file.")

    private fun newExtractor(source: Source): MediaExtractor {
        val ex = MediaExtractor()
        try {
            if (source.file != null) ex.setDataSource(source.file.absolutePath)
            else ex.setDataSource(context, source.uri!!, null)
        } catch (e: Exception) {
            ex.release()
            throw IllegalStateException("Android could not read this media file.")
        }
        return ex
    }

    private fun detectFormat(source: Source, name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "mp3") return "mp3"
        if (ext == "wav" || ext == "wave") return "wav"
        if (ext in setOf("mp4", "m4a", "m4v", "m4b", "mov", "3gp", "aac", "webm", "mkv")) return "container"
        val head = ByteArray(12)
        val n = try {
            openInput(source).use { readFully(it, head, 0, 12) }
        } catch (_: Exception) {
            0
        }
        if (n >= 12 && String(head, 0, 4, Charsets.ISO_8859_1) == "RIFF" &&
            String(head, 8, 4, Charsets.ISO_8859_1) == "WAVE") return "wav"
        if (n >= 3 && String(head, 0, 3, Charsets.ISO_8859_1) == "ID3") return "mp3"
        if (n >= 4 && Mp3Header.parse(head, 0) != null) return "mp3"
        return "container"
    }

    // ---------------------------------------------------------------- MP4 / M4A / WebM

    /** Returns true when the output is WebM, false for MP4. */
    private fun muxCut(source: Source, output: File, audioOnly: Boolean, ranges: List<LongArray>): Boolean {
        val probe = newExtractor(source)
        val trackFormats = LinkedHashMap<Int, MediaFormat>()
        var rotation = 0
        var maxInput = 1024 * 1024
        try {
            for (i in 0 until probe.trackCount) {
                val format = probe.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                val include = if (audioOnly) mime.startsWith("audio/")
                              else mime.startsWith("audio/") || mime.startsWith("video/")
                if (!include) continue
                trackFormats[i] = format
                if (mime.startsWith("video/") && format.containsKey(MediaFormat.KEY_ROTATION)) {
                    rotation = format.getInteger(MediaFormat.KEY_ROTATION)
                }
                if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    maxInput = maxOf(maxInput, format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                }
            }
        } finally {
            probe.release()
        }
        require(trackFormats.isNotEmpty()) { "No audio or video track was found in this file." }

        val mimes = trackFormats.values.map { it.getString(MediaFormat.KEY_MIME) ?: "" }
        val webmMimes = setOf(
            MediaFormat.MIMETYPE_VIDEO_VP8, MediaFormat.MIMETYPE_VIDEO_VP9,
            MediaFormat.MIMETYPE_AUDIO_VORBIS, MediaFormat.MIMETYPE_AUDIO_OPUS
        )
        val webm = mimes.all { it in webmMimes }
        val mp4Ok = setOf(
            MediaFormat.MIMETYPE_VIDEO_AVC, MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_MPEG4,
            MediaFormat.MIMETYPE_VIDEO_H263, "video/av01",
            MediaFormat.MIMETYPE_AUDIO_AAC, MediaFormat.MIMETYPE_AUDIO_AMR_NB, MediaFormat.MIMETYPE_AUDIO_AMR_WB
        )
        if (!webm) {
            val bad = mimes.filter { it !in mp4Ok }
            require(bad.isEmpty()) {
                "This file uses " + bad.joinToString { it.substringAfter('/') } +
                    ", which Android cannot save without re-encoding. MP3, WAV, AAC/M4A, MP4 (H.264/H.265) and WebM work."
            }
        }

        val muxer = MediaMuxer(
            output.absolutePath,
            if (webm) MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )
        var started = false
        var wroteAny = false
        try {
            val trackMap = HashMap<Int, Int>()
            for ((index, format) in trackFormats) trackMap[index] = muxer.addTrack(format)
            if (!webm && rotation != 0) muxer.setOrientationHint(rotation)
            muxer.start()
            started = true

            val buffer = ByteBuffer.allocate(maxInput.coerceAtMost(32 * 1024 * 1024))
            var offsetUs = 0L
            for (range in ranges) {
                val lastUs = writeSegment(source, muxer, trackMap, buffer, range[0], range[1], offsetUs)
                if (lastUs >= 0) {
                    wroteAny = true
                    offsetUs = lastUs + 20_000L // small gap keeps timestamps increasing between parts
                }
            }
        } finally {
            if (started) {
                try {
                    muxer.stop()
                } catch (_: Exception) {
                }
            }
            try {
                muxer.release()
            } catch (_: Exception) {
            }
        }
        require(wroteAny && output.length() > 0) { "The selected range contained no media to save." }
        return webm
    }

    /** Copies samples from the keyframe at or before fromUs up to toUs. Returns the last output time, or -1. */
    private fun writeSegment(
        source: Source, muxer: MediaMuxer, trackMap: Map<Int, Int>, buffer: ByteBuffer,
        fromUs: Long, toUs: Long, outputOffsetUs: Long
    ): Long {
        val ex = newExtractor(source)
        var lastOut = -1L
        try {
            trackMap.keys.forEach { ex.selectTrack(it) }
            ex.seekTo(fromUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val info = MediaCodec.BufferInfo()
            var baseUs = -1L
            while (true) {
                val track = ex.sampleTrackIndex
                val timeUs = ex.sampleTime
                if (track < 0 || timeUs < 0) break
                if (toUs != Long.MAX_VALUE && timeUs >= toUs) break
                val out = trackMap[track]
                if (out != null) {
                    if (baseUs < 0) baseUs = timeUs
                    if (timeUs >= baseUs) { // skips leading frames that belong to the previous group
                        buffer.clear()
                        val size = ex.readSampleData(buffer, 0)
                        if (size > 0) {
                            val pts = outputOffsetUs + (timeUs - baseUs)
                            info.set(0, size, pts, ex.sampleFlags)
                            muxer.writeSampleData(out, buffer, info)
                            if (pts > lastOut) lastOut = pts
                        }
                    }
                }
                if (!ex.advance()) break
            }
        } finally {
            ex.release()
        }
        return lastOut
    }

    // ---------------------------------------------------------------- MP3

    private class Mp3Header(
        val version: Int, val layer: Int, val sampleRate: Int,
        val frameLength: Int, val samples: Int, val mono: Boolean
    ) {
        companion object {
            private val BR_V1_L1 = intArrayOf(0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448)
            private val BR_V1_L2 = intArrayOf(0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384)
            private val BR_V1_L3 = intArrayOf(0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
            private val BR_V2_L1 = intArrayOf(0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256)
            private val BR_V2_L23 = intArrayOf(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160)

            /** version: 1 = MPEG-1, 2 = MPEG-2, 25 = MPEG-2.5. layer: 1, 2 or 3. */
            fun parse(b: ByteArray, off: Int): Mp3Header? {
                val b0 = b[off].toInt() and 0xFF
                val b1 = b[off + 1].toInt() and 0xFF
                val b2 = b[off + 2].toInt() and 0xFF
                val b3 = b[off + 3].toInt() and 0xFF
                if (b0 != 0xFF || (b1 and 0xE0) != 0xE0) return null
                val version = when ((b1 shr 3) and 3) { 0 -> 25; 2 -> 2; 3 -> 1; else -> return null }
                val layer = when ((b1 shr 1) and 3) { 1 -> 3; 2 -> 2; 3 -> 1; else -> return null }
                val brIdx = (b2 shr 4) and 0xF
                if (brIdx == 0 || brIdx == 15) return null
                val srIdx = (b2 shr 2) and 3
                if (srIdx == 3) return null
                val padding = (b2 shr 1) and 1
                val mono = ((b3 shr 6) and 3) == 3
                val sampleRate = when (version) {
                    1 -> intArrayOf(44100, 48000, 32000)[srIdx]
                    2 -> intArrayOf(22050, 24000, 16000)[srIdx]
                    else -> intArrayOf(11025, 12000, 8000)[srIdx]
                }
                val kbps = if (version == 1) {
                    when (layer) {
                        1 -> BR_V1_L1[brIdx]
                        2 -> BR_V1_L2[brIdx]
                        else -> BR_V1_L3[brIdx]
                    }
                } else {
                    if (layer == 1) BR_V2_L1[brIdx] else BR_V2_L23[brIdx]
                }
                val bps = kbps * 1000
                val frameLength = when {
                    layer == 1 -> (12 * bps / sampleRate + padding) * 4
                    layer == 3 && version != 1 -> 72 * bps / sampleRate + padding
                    else -> 144 * bps / sampleRate + padding
                }
                val samples = when {
                    layer == 1 -> 384
                    layer == 3 && version != 1 -> 576
                    else -> 1152
                }
                if (frameLength < 21) return null
                return Mp3Header(version, layer, sampleRate, frameLength, samples, mono)
            }
        }
    }

    private fun cutMp3(source: Source, output: File, ranges: List<LongArray>) {
        var frames = 0
        var kept = 0
        var written = 0L
        var xingFrame: ByteArray? = null
        var xingTagOffset = 0
        var xingPos = -1L
        var audioBytes = 0L
        var offsets = LongArray(4096) // byte offset of each kept frame, for the seek table
        openInput(source).use { raw ->
            val input = BufferedInputStream(raw, 1 shl 16)
            FileOutputStream(output).use { fileOut ->
                val out = fileOut.buffered(1 shl 16)
                // ID3v2 tag (title, artist, cover) is copied once at the start.
                val head = ByteArray(10)
                input.mark(16)
                val n = readFully(input, head, 0, 10)
                if (n == 10 && head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte()) {
                    val size = ((head[6].toInt() and 0x7F) shl 21) or ((head[7].toInt() and 0x7F) shl 14) or
                        ((head[8].toInt() and 0x7F) shl 7) or (head[9].toInt() and 0x7F)
                    val footer = if ((head[5].toInt() and 0x10) != 0) 10 else 0
                    out.write(head)
                    written += 10
                    written += copyBytes(input, out, (size + footer).toLong())
                } else {
                    input.reset()
                }

                val hdr = ByteArray(4)
                val frame = ByteArray(8192)
                var timeUs = 0.0
                var lockVersion = -1
                var lockLayer = -1
                var lockRate = -1
                var junk = 0L
                while (true) {
                    input.mark(8)
                    if (readFully(input, hdr, 0, 4) < 4) break
                    val h = Mp3Header.parse(hdr, 0)
                    val matches = h != null && (lockVersion < 0 ||
                        (h.version == lockVersion && h.layer == lockLayer && h.sampleRate == lockRate))
                    if (h == null || !matches) {
                        input.reset()
                        if (input.skip(1) < 1) break
                        junk++
                        if (frames > 0 && junk > 1_000_000) break // trailing tags/garbage
                        continue
                    }
                    junk = 0
                    System.arraycopy(hdr, 0, frame, 0, 4)
                    if (readFully(input, frame, 4, h.frameLength - 4) < h.frameLength - 4) break
                    if (lockVersion < 0) {
                        lockVersion = h.version
                        lockLayer = h.layer
                        lockRate = h.sampleRate
                        // The Xing/Info header frame holds length and seek data; keep it and rewrite it below.
                        val side = if (h.version == 1) (if (h.mono) 17 else 32) else (if (h.mono) 9 else 17)
                        val tag = if (4 + side + 8 <= h.frameLength) String(frame, 4 + side, 4, Charsets.ISO_8859_1) else ""
                        if (tag == "Xing" || tag == "Info") {
                            xingFrame = frame.copyOf(h.frameLength)
                            xingTagOffset = 4 + side
                            xingPos = written
                            out.write(frame, 0, h.frameLength)
                            written += h.frameLength
                            continue
                        }
                        if (h.frameLength >= 40 && String(frame, 36, 4, Charsets.ISO_8859_1) == "VBRI") continue
                    }
                    frames++
                    val durUs = h.samples * 1_000_000.0 / h.sampleRate
                    val start = timeUs
                    val end = timeUs + durUs
                    timeUs = end
                    // Keep any frame that overlaps a kept range, so kept audio is never trimmed.
                    val keep = ranges.any { r -> end > r[0] && (r[1] == Long.MAX_VALUE || start < r[1]) }
                    if (keep) {
                        if (kept == offsets.size) offsets = offsets.copyOf(offsets.size * 2)
                        offsets[kept] = audioBytes
                        out.write(frame, 0, h.frameLength)
                        written += h.frameLength
                        audioBytes += h.frameLength
                        kept++
                    }
                }
                out.flush()
            }
        }
        require(frames > 0) { "No MP3 audio frames were found in this file." }
        require(kept > 0) { "The selected range contained no audio to save." }

        val xf = xingFrame
        if (xf != null && xingPos >= 0) {
            patchXing(xf, xingTagOffset, kept, audioBytes, offsets)
            RandomAccessFile(output, "rw").use { f ->
                f.seek(xingPos)
                f.write(xf)
            }
        }
    }

    /** Updates frame count, byte count, seek table and LAME CRC so players show the new length. */
    private fun patchXing(fr: ByteArray, tagOff: Int, kept: Int, audioBytes: Long, offsets: LongArray) {
        fun putBE32(pos: Int, v: Long) {
            if (pos + 4 > fr.size) return
            fr[pos] = (v shr 24).toByte()
            fr[pos + 1] = (v shr 16).toByte()
            fr[pos + 2] = (v shr 8).toByte()
            fr[pos + 3] = v.toByte()
        }
        if (tagOff + 8 > fr.size) return
        val flags = ((fr[tagOff + 4].toInt() and 0xFF) shl 24) or ((fr[tagOff + 5].toInt() and 0xFF) shl 16) or
            ((fr[tagOff + 6].toInt() and 0xFF) shl 8) or (fr[tagOff + 7].toInt() and 0xFF)
        val total = fr.size.toLong() + audioBytes
        var q = tagOff + 8
        if ((flags and 1) != 0) {
            putBE32(q, kept.toLong())
            q += 4
        }
        if ((flags and 2) != 0) {
            putBE32(q, total)
            q += 4
        }
        if ((flags and 4) != 0 && q + 100 <= fr.size) {
            for (i in 0 until 100) {
                val k = minOf(kept - 1, (i.toLong() * kept / 100).toInt())
                val pos = fr.size.toLong() + offsets[k]
                fr[q + i] = minOf(255L, pos * 256 / total).toByte()
            }
        }
        if (fr.size >= 192 && tagOff + 124 <= fr.size) {
            val enc = String(fr, tagOff + 120, 4, Charsets.ISO_8859_1)
            if (enc == "LAME" || enc == "Lavc" || enc == "Lavf" || enc == "GOGO") {
                var crc = 0
                for (i in 0 until 190) {
                    crc = crc xor (fr[i].toInt() and 0xFF)
                    for (bit in 0 until 8) {
                        crc = if ((crc and 1) != 0) (crc ushr 1) xor 0xA001 else crc ushr 1
                    }
                }
                fr[190] = (crc shr 8).toByte()
                fr[191] = crc.toByte()
            }
        }
    }

    // ---------------------------------------------------------------- WAV

    private fun cutWav(source: Source, output: File, ranges: List<LongArray>) {
        openInput(source).use { raw ->
            val input = BufferedInputStream(raw, 1 shl 16)
            val riff = ByteArray(12)
            require(readFully(input, riff, 0, 12) == 12 &&
                String(riff, 0, 4, Charsets.ISO_8859_1) == "RIFF" &&
                String(riff, 8, 4, Charsets.ISO_8859_1) == "WAVE") { "This WAV file is not readable." }
            var fmt: ByteArray? = null
            val chunk = ByteArray(8)
            while (true) {
                require(readFully(input, chunk, 0, 8) == 8) { "No audio data was found in this WAV file." }
                val id = String(chunk, 0, 4, Charsets.ISO_8859_1)
                val size = le32(chunk, 4)
                if (id == "fmt ") {
                    val f = ByteArray(size.toInt())
                    require(readFully(input, f, 0, f.size) == f.size) { "This WAV file is damaged." }
                    if (size % 2 == 1L) input.skip(1)
                    fmt = f
                } else if (id == "data") {
                    val f = fmt ?: throw IllegalStateException("This WAV file has no format information.")
                    require(f.size >= 16) { "This WAV file is damaged." }
                    val byteRate = le32(f, 8)
                    val blockAlign = ((f[12].toInt() and 0xFF) or ((f[13].toInt() and 0xFF) shl 8)).toLong()
                    require(byteRate > 0 && blockAlign > 0) { "This WAV file is damaged." }
                    val dataSize = if (size == 0L || size == 0xFFFFFFFFL) Long.MAX_VALUE else size
                    fun byteAt(us: Long): Long =
                        if (us == Long.MAX_VALUE) Long.MAX_VALUE
                        else (us.toDouble() * byteRate / 1_000_000.0 / blockAlign).toLong() * blockAlign

                    RandomAccessFile(output, "rw").use { out ->
                        out.setLength(0)
                        out.write(ByteArray(12 + 8 + f.size + 8)) // header written at the end
                        var pos = 0L
                        var written = 0L
                        val buf = ByteArray(1 shl 16)
                        for (r in ranges) {
                            val a = minOf(byteAt(r[0]), dataSize)
                            val b = minOf(byteAt(r[1]), dataSize)
                            if (a > pos) {
                                pos += skipFully(input, a - pos)
                                if (pos < a) break
                            }
                            var remaining = b - pos
                            while (remaining > 0) {
                                val read = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                                if (read <= 0) break
                                out.write(buf, 0, read)
                                remaining -= read
                                pos += read
                                written += read
                            }
                        }
                        require(written > 0) { "The selected range contained no audio to save." }
                        if (written % 2 == 1L) out.write(0)
                        out.seek(0)
                        out.write("RIFF".toByteArray(Charsets.ISO_8859_1))
                        out.write(le32Bytes(4 + 8 + f.size + 8 + written + (written % 2)))
                        out.write("WAVEfmt ".toByteArray(Charsets.ISO_8859_1))
                        out.write(le32Bytes(f.size.toLong()))
                        out.write(f)
                        out.write("data".toByteArray(Charsets.ISO_8859_1))
                        out.write(le32Bytes(written))
                    }
                    return
                } else {
                    val skip = size + (size % 2)
                    require(skipFully(input, skip) == skip) { "No audio data was found in this WAV file." }
                }
            }
        }
    }

    // ---------------------------------------------------------------- saving

    private enum class Kind { VIDEO, AUDIO, IMAGE }

    private fun publishOutput(temp: File, kind: Kind, displayName: String, mime: String): String {
        val folder = when (kind) {
            Kind.VIDEO -> Environment.DIRECTORY_MOVIES
            Kind.AUDIO -> Environment.DIRECTORY_MUSIC
            Kind.IMAGE -> Environment.DIRECTORY_PICTURES
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val collection: Uri = when (kind) {
                Kind.VIDEO -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                Kind.AUDIO -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                Kind.IMAGE -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/MYmusicCuts")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(collection, values)
                ?: throw IllegalStateException("Android could not create the output file.")
            try {
                val stream = context.contentResolver.openOutputStream(uri, "w")
                    ?: throw IllegalStateException("Android could not write the output file.")
                stream.use { out -> temp.inputStream().use { it.copyTo(out) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(uri, done, null, null)
                return "$folder/MYmusicCuts/$displayName"
            } catch (e: Exception) {
                context.contentResolver.delete(uri, null, null)
                throw e
            }
        }

        // Android 9 and older.
        val canWritePublic = context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
        val root = if (canWritePublic) {
            publicDirectory(folder)
        } else {
            context.getExternalFilesDir(folder) ?: context.filesDir
        }
        val dir = File(root, "MYmusicCuts").apply { mkdirs() }
        val dest = File(dir, displayName)
        temp.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf(mime), null)
        return dest.absolutePath
    }

    // ---------------------------------------------------------------- helpers

    @Suppress("DEPRECATION")
    private fun publicDirectory(folder: String): File = Environment.getExternalStoragePublicDirectory(folder)

    private fun notifyPage(message: String) {
        val quoted = JSONObject.quote(message)
        webView.post {
            webView.evaluateJavascript(
                "if(window.onNativeCutterResult){window.onNativeCutterResult($quoted);}", null
            )
        }
    }

    private fun safeName(value: String): String {
        val cleaned = value.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_', '.')
        return cleaned.ifBlank { "media" }
    }

    private fun readFully(input: InputStream, buf: ByteArray, off: Int, len: Int): Int {
        var total = 0
        while (total < len) {
            val n = input.read(buf, off + total, len - total)
            if (n <= 0) break
            total += n
        }
        return total
    }

    private fun skipFully(input: InputStream, count: Long): Long {
        var done = 0L
        val scratch = ByteArray(8192)
        while (done < count) {
            val skipped = input.skip(count - done)
            if (skipped > 0) {
                done += skipped
                continue
            }
            val n = input.read(scratch, 0, minOf(scratch.size.toLong(), count - done).toInt())
            if (n <= 0) break
            done += n
        }
        return done
    }

    private fun copyBytes(input: InputStream, out: OutputStream, count: Long): Long {
        val buf = ByteArray(1 shl 16)
        var remaining = count
        var done = 0L
        while (remaining > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
            if (n <= 0) break
            out.write(buf, 0, n)
            remaining -= n
            done += n
        }
        return done
    }

    private fun le32(b: ByteArray, off: Int): Long =
        ((b[off].toLong() and 0xFF) or ((b[off + 1].toLong() and 0xFF) shl 8) or
            ((b[off + 2].toLong() and 0xFF) shl 16) or ((b[off + 3].toLong() and 0xFF) shl 24))

    private fun le32Bytes(v: Long): ByteArray =
        byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
}
