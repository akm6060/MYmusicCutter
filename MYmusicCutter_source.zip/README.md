# MYmusic Cutter (native Android)

The cutter interface (`app/src/main/assets/index.html`) runs inside a native WebView.
Kotlin code does the cutting, saving, landscape lock and fullscreen.

## Build on GitHub
Either way works:
- **iPad / single file:** create a new repository, upload `MYmusicCutter_source.zip` as one file,
  then use *Add file → Create new file*, name it `.github/workflows/build-apk.yml` and paste the
  workflow text. The workflow unpacks the ZIP itself.
- **Computer:** extract the ZIP and upload its *contents* so `settings.gradle` and the `.github`
  folder sit at the top level of the repository (not inside a sub-folder).

Then open **Actions → Build MYmusic Cutter APK**. The APK is in the run's *Artifacts*.

## What the app does
- Opens straight into the portrait cutter. The video area matches the video's shape; sliders fill the rest.
- Portrait: tap the video to play/pause. Fullscreen: tap left third -5 s, right third +5 s, centre play/pause;
  one-finger swipe seeks; two fingers pinch-zoom and move the picture anywhere (at least 20% stays on screen).
  Leaving fullscreen or "Reset picture" puts it back.
- Equalizer page (button on the video): 8 bands, bass, clarity at 8 kHz (±15 dB), HRTF virtual surround,
  click & pop repair, hiss/hum/rumble reduction, auto enhancer, and a limiter (on by default).
  Sound is untouched until a setting is changed.
- Back / edge swipe: closes the equalizer, then leaves fullscreen; on the main screen a second Back within
  2 seconds stops playback and closes the app. Playback pauses whenever the app leaves the screen.
- Swipes over the cutter timeline are not treated as the Back gesture (Android 10+).
- Results are saved as "original name N" (my song 1.mp3, my song 2.mp3, ...).

## Cutting (no re-encoding)
| File | Output | Notes |
|---|---|---|
| MP3 | .mp3 | Whole frames (~26 ms) copied; length/seek header rewritten |
| WAV | .wav | Exact to the sample |
| MP4 / M4A / 3GP / MOV / AAC (H.264, H.265, AAC) | .mp4 / .m4a | Video starts at the keyframe at or before your start point |
| WebM / OGG / Opus (VP8, VP9, Vorbis, Opus) | .webm | Same keyframe rule |
| FLAC, AC3, MP3-inside-video, etc. | — | Reported as unsupported; nothing is saved |

Video goes to `Movies/MYmusicCuts`, audio to `Music/MYmusicCuts`. The original is never changed.
Results keep the original name plus a number: `my song.mp3` → `my song 1.mp3`, then `my song 2.mp3`, and so on
(numbered per name within each folder). Snapshots follow the same rule in `Pictures/MYmusicCuts`.
The file is read directly from what you picked; copying through JavaScript is only a fallback.
On Android 9 and older the app asks for storage permission so it can save into those public folders.

## Status
Not yet compiled or tested on a device. Record the exact error text and Android version for any failure.
