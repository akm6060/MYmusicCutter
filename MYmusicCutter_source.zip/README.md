# MYmusic Cutter (native Android)

The cutter interface (`app/src/main/assets/index.html`) runs inside a native WebView.
Kotlin code does the cutting, saving, landscape lock and fullscreen.

## Build on GitHub
Either way works:
- **iPad / single file:** create a new repository, upload `MYmusicCutter_source.zip` as one file,
  then use *Add file → Create new file*, name it `.github/workflows/build-apk.yml` and paste the
  workflow text. The workflow unpacks the ZIP itself.
- **Computer:** extract the ZIP and upload its *contents* so `settings.gradle` and the `.github`
  folder sit at the top level of the repository (not inside a sub-folder).

Then open **Actions → Build MYmusic Cutter APK**. The APK is in the run's *Artifacts*.

## What the app does
- Opens straight into the portrait cutter. No equalizer, no volume slider; playback stays at full level
  directly from the media element (no Web Audio processing).
- Fullscreen video turns to landscape and hides the status and navigation bars. Back leaves fullscreen.
- Multi-file selection works (the picker result is read natively).
- Snapshot JPEG saves to `Pictures/MYmusicCuts`.

## Cutting (no re-encoding)
| File | Output | Notes |
|---|---|---|
| MP3 | .mp3 | Whole frames (~26 ms) copied; length/seek header rewritten |
| WAV | .wav | Exact to the sample |
| MP4 / M4A / 3GP / MOV / AAC (H.264, H.265, AAC) | .mp4 / .m4a | Video starts at the keyframe at or before your start point |
| WebM / OGG / Opus (VP8, VP9, Vorbis, Opus) | .webm | Same keyframe rule |
| FLAC, AC3, MP3-inside-video, etc. | — | Reported as unsupported; nothing is saved |

Video goes to `Movies/MYmusicCuts`, audio to `Music/MYmusicCuts`. The original is never changed.
Results keep the original name plus a number: `my song.mp3` → `my song 1.mp3`, then `my song 2.mp3`, and so on
(numbered per name within each folder). Snapshots follow the same rule in `Pictures/MYmusicCuts`.
The file is read directly from what you picked; copying through JavaScript is only a fallback.
On Android 9 and older the app asks for storage permission so it can save into those public folders.

## Status
Not yet compiled or tested on a device. Record the exact error text and Android version for any failure.
